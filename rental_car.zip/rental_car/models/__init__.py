# -*- coding: utf-8 -*-

from . import account_move
from . import sale_order_line
from . import sale_order
from . import product
from . import fleet
from . import salik_gates
from . import Salik_car_transaction
from . import pickup
from . import car_fines
